import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css'],
  providers : [AppService]
})
export class MembersComponent implements OnInit {
  members: any[] = [];
  memberUpdateForm !: FormGroup;
  teams:any=[];
  updateBoxEnable=false;
  editMemberId="";
  doneStatus=false;
  constructor(public appService: AppService, private router: Router , private fBuilder : FormBuilder) { }

  ngOnInit(): void {
    this.getMembers()
    this.genrateForm();
  }
  genrateForm(){
    this.memberUpdateForm = this.fBuilder.group({
      firstName : ['' , [Validators.required]],
      lastName : ['' , [Validators.required]],
      jobTitle : ['' , [Validators.required]],
      team : ['' , [Validators.required]],
      status : ['', [Validators.required] ]
    })
  }



  getMembers(){
    this.appService.getMembers().subscribe((members: any) =>{
      if(members.statusCode == 200){
        this.members = members.data;
       
      }else{
        this.members = [];
      }
    } );
  }



  deleteMember(member:any){
    this.appService.deleteMember(member.id).subscribe((result: any) =>{
      console.log(result)
      if(result.statusCode == 200){
        this.getMembers()
      }else{
      }
    } );
  }


  editMember(member:any){
    this.editMemberId = member.id;
    this.updateBoxEnable=true;
    this.getTeams()
    this.memberUpdateForm.patchValue({
        firstName : member.firstName,
        lastName : member.lastName,
        jobTitle : member.jobTitle,
        team : member.team,
        status : member.status
    })
  }

  changeTeam(e: any) {
    this.memberUpdateForm?.patchValue({
      team  : e.target.value
    });
  }

  getTeams(){
    this.appService.getTeams().subscribe((result:any)=>{
         if(result.statusCode == 200){
          this.teams = result.data;
         }
       })
     }

  updateMember(){
    let data = {
      "id" :  this.editMemberId,
      "firstName" : this.memberUpdateForm.controls.firstName.value,
      "lastName" : this.memberUpdateForm.controls.lastName.value,
      "jobTitle" : this.memberUpdateForm.controls.jobTitle.value,
      "team" :this.memberUpdateForm.controls.team.value,
      "status": this.memberUpdateForm.controls.status.value,
    }
    console.log(data)
    this.appService.updateMember(data).subscribe((result:any)=>{
        console.log(result);
      if(result.statusCode == 200){
        this.getMembers();
        this.doneStatus = true;
        setTimeout(()=>{
          this.doneStatus = false;
          this.updateBoxEnable=false;
        },3000)
      }else{

      }
    })
  }
}
