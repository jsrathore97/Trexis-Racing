import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MembersComponent } from './members.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppService } from '../app.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('MembersComponent', () => {
  let component: MembersComponent;
  let fixture: ComponentFixture<MembersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MembersComponent ],
      imports: [
        ReactiveFormsModule,
        FormsModule,HttpClientModule,RouterTestingModule
    ],
      providers: [AppService],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MembersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
});

it('form invalid when empty', () => {
    expect(component.memberUpdateForm.valid).toBeFalsy();
});

it('name field validity', () => {
    let fname = component.memberUpdateForm.controls['firstName'];
    expect(fname.valid).toBeFalsy();

    fname.setValue("");
    expect(fname.hasError('required')).toBeTruthy();

    let lname = component.memberUpdateForm.controls['lastName'];
    expect(lname.valid).toBeFalsy();

    lname.setValue("");
    expect(lname.hasError('required')).toBeTruthy();

    let jobT = component.memberUpdateForm.controls['jobTitle'];
    expect(jobT.valid).toBeFalsy();

    jobT.setValue("");
    expect(jobT.hasError('required')).toBeTruthy();

    let team_ = component.memberUpdateForm.controls['team'];
    expect(team_.valid).toBeFalsy();

    team_.setValue("");
    expect(team_.hasError('required')).toBeTruthy();

    let status_ = component.memberUpdateForm.controls['status'];
    expect(status_.valid).toBeFalsy();

    status_.setValue("");
    expect(status_.hasError('required')).toBeTruthy();

    
});


});
