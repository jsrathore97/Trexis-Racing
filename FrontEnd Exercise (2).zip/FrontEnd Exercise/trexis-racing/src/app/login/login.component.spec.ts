import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import {HttpClientModule} from '@angular/common/http';
import { AppService } from '../app.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormBuilder } from '@angular/forms';
describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      providers : [AppService , FormBuilder],
      imports: [ RouterTestingModule  , HttpClientModule ],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.loginForm.valid).toBeFalsy();
});

it('name field validity', () => {
    let username_ = component.loginForm.controls['username'];
    expect(username_.valid).toBeFalsy();

    username_.setValue("");
    expect(username_.hasError('required')).toBeTruthy();

    let password_ = component.loginForm.controls['password'];
    expect(password_.valid).toBeFalsy();

    password_.setValue("");
    expect(password_.hasError('required')).toBeTruthy();

    

   

    
});


});
