import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[AppService]
})
export class LoginComponent implements OnInit {
loginForm !: FormGroup;
loginStatus:any="";

  constructor(private router: Router, private appService: AppService , private fBuilder : FormBuilder) { }

  ngOnInit(): void {
    this.genrateLoginForm()
  }

  genrateLoginForm(){
    this.loginForm = this.fBuilder.group({
      username : ['' , [Validators.required]],
      password : ['' , [Validators.required]]
    })
  }

  login() {
    if(this.loginForm.controls.username.value == "JITENDRA" &&  this.loginForm.controls.password.value == "JITENDRA@123" ){
        this.loginStatus = true;
        sessionStorage.setItem('token' , "UserLoggedIn")
        setTimeout(()=>{
          this.loginStatus = "";
          this.router.navigate(['/members']);
        },2000)
    }else{
      this.loginStatus = false;
    }
  }

}
