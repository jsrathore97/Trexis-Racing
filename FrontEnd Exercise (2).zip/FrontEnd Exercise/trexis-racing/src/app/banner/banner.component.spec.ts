import { ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { BannerComponent } from './banner.component';
import {HttpClientModule} from '@angular/common/http';
import { AppService } from '../app.service';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
describe('BannerComponent', () => {
  let component: BannerComponent;
  let fixture: ComponentFixture<BannerComponent>;

  


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BannerComponent ],
      providers:[AppService],
      imports: [ RouterTestingModule  , HttpClientModule ],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
