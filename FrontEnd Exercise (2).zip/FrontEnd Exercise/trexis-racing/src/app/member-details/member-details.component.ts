import { Component, OnInit, OnChanges } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

export interface Member {
  id: number;
  firstName: string;
  lastName: string;
  jobTitle: string;
  team: string;
  status: string;
}

@Component({
  selector: 'app-member-details',
  templateUrl: './member-details.component.html',
  styleUrls: ['./member-details.component.css']
})
export class MemberDetailsComponent implements OnInit, OnChanges {
  doneStatus=false;
  teams:any = [];
  memberForm !: FormGroup;
  submitted=false;
  constructor(private appService: AppService, private router: Router , private fBuilder : FormBuilder) { }

  ngOnInit(): void {
    this.getTeams()
    this.genrateForm()
  } 

  genrateForm(){
    this.memberForm = this.fBuilder.group({
      firstName : ['' , [Validators.required]],
      lastName : ['' , [Validators.required]],
      jobTitle : ['' , [Validators.required]],
      team : ['' , [Validators.required]],
      status : ['Active'  , [Validators.required]]
    })
  }


  getTeams(){
 this.appService.getTeams().subscribe((result:any)=>{
      if(result.statusCode == 200){
       this.teams = result.data;
      }
    })
  }

  changeTeam(e: any) {
    this.memberForm?.patchValue({
      team  : e.target.value
    });
  }



  ngOnChanges() { }

   // TODO: Add member to members
   onSubmit(){
    console.log(this.memberForm)
    let data = {
      "firstName" : this.memberForm.controls.firstName.value,
      "lastName" : this.memberForm.controls.lastName.value,
      "jobTitle" : this.memberForm.controls.jobTitle.value,
      "team" :this.memberForm.controls.team.value,
      "status": this.memberForm.controls.status.value
    }
     console.log(data);
    this.appService.addMember(data).subscribe((result:any)=>{
      if(result.statusCode == 200){
        this.doneStatus=true;
        setTimeout(()=>{ this.doneStatus = false; 
          this.router.navigateByUrl('members')
        },3000);
      }
    })
   }
  

}
