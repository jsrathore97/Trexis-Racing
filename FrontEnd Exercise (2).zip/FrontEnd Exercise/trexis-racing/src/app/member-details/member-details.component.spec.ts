import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberDetailsComponent } from './member-details.component';
import { AppService } from '../app.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { FormBuilder } from '@angular/forms';

describe('MemberDetailsComponent', () => {
  let component: MemberDetailsComponent;
  let fixture: ComponentFixture<MemberDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberDetailsComponent ],
      providers: [AppService , FormBuilder],
      imports: [ RouterTestingModule  , HttpClientModule  ],
    })
    .compileComponents();

  
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.memberForm.valid).toBeFalsy();
});

it('name field validity', () => {
    let fname = component.memberForm.controls['firstName'];
    expect(fname.valid).toBeFalsy();

    fname.setValue("");
    expect(fname.hasError('required')).toBeTruthy();

    let lname = component.memberForm.controls['lastName'];
    expect(lname.valid).toBeFalsy();

    lname.setValue("");
    expect(lname.hasError('required')).toBeTruthy();

    let jobT = component.memberForm.controls['jobTitle'];
    expect(jobT.valid).toBeFalsy();

    jobT.setValue("");
    expect(jobT.hasError('required')).toBeTruthy();

    let team_ = component.memberForm.controls['team'];
    expect(team_.valid).toBeFalsy();

    team_.setValue("");
    expect(team_.hasError('required')).toBeTruthy();

   

    
});


});
