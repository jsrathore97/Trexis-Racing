const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const helmet = require('helmet');
var hsts = require('hsts');
const path = require('path');
var xssFilter = require('x-xss-protection');
var nosniff = require('dont-sniff-mimetype');
const request = require('request');
var fs = require('fs')

// var fetch = require('node-fetch')
const app = express();

app.use(cors());
app.use(express.static('assets'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.disable('x-powered-by');
app.use(xssFilter());
app.use(nosniff());
app.set('etag', false);
app.use(
  helmet({
    noCache: true
  })
);
app.use(
  hsts({
    maxAge: 15552000 // 180 days in seconds
  })
);


// Global Variable for Storing , Getting , Updating the Members...
var membersMasterData=[];


app.use(
  express.static(path.join(__dirname, 'dist/trexis-racing'), {
    etag: false
  })
);

app.get('/api/members', (req, res) => {
  const members = JSON.parse(fs.readFileSync('db.json')).members;
  res.json({statusCode : 200 , data : members})
});


app.get('/api/teams', (req, res) => {
  fs.readFile('team.json', function (err, data) {
    var json = JSON.parse(data)
    res.json({statusCode : 200 , data : json.teams})

    // fs.writeFile("results.json", JSON.stringify(json))
})


});

app.get('/api/members/:id', (req, res) => {
  let options = {
      url: 'http://localhost:3000/members/' + req.params.id
  };
  request.get(options, (err, response, body) => {
    if (response.statusCode <= 500) {
      res.send(body);
    }
  });
 
});

// Submit Form!
app.post('/api/addMember', (req, res) => {
  let id_ = Math.random().toString(36).slice(2);
  let saveBody = req.body;
  saveBody.id = id_; 

  const members = JSON.parse(fs.readFileSync('db.json')).members;
  members.push(saveBody);
  fs.writeFileSync("db.json" , JSON.stringify({members}));
res.json({"statusCode" : 200 , "data" : req.body})








  // membersMasterData.push(req.body);
});

app.put('/api/members/:id', (req, res) => {
 
  let options = {
      url: 'http://localhost:3000/members/' + req.params.id,
      form: req.body
  };

  request.put(options, (err, response, body) => {
    if (response.statusCode <= 500) {
      res.send(body);
    }
  });
 
});

app.post('/api/member/delete', (req, res) => {
  const members = JSON.parse(fs.readFileSync('db.json')).members;
  const userIndex = members.findIndex((data)=> data.id === req.body.id)
  console.log(req.body.id    ,   "              " , userIndex)
  if(userIndex === -1) return res.status(404).send("Member Not Found")
  members.splice(userIndex,1);
  fs.writeFileSync("db.json" , JSON.stringify({members}))
  res.json({statusCode : 200  , "message" : "Member Deleted"}); 
});


app.post('/api/member/update', (req, res) => {
  const members = JSON.parse(fs.readFileSync('db.json')).members;
  console.log("memmmmmmmmmmmmmmm             >>>>>>  ",members);
  console.log("req.body.id >>>>>>>>>>>>>>>>    ",req.body.id)
  const member = members.find((data)=> data.id === req.body.id)
  if(!member) return res.status(404).send("Member Not Found")

  Object.assign(member,req.body);
  fs.writeFileSync("db.json" , JSON.stringify({members}))
  res.json({statusCode : 200  , "message" : "Member Updated"}); 


  // console.log(req.body.id    ,   "              " , userIndex)
  // members.splice(userIndex,1);
});


app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/trexis-racing/index.html'));
});

app.listen('8000', () => {
  console.log('Vrrrum Vrrrum! Server starting!');
});
